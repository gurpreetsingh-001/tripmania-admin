const express = require('express');
const Category = require('../models/categoryModel');
const jwtHandler = require('../utils/jwtHandler');

const router = express.Router();

// Get all categories
router.get('/', async (req, res) => {
    try {
        const categories = await Category.find();
        res.json(categories);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Internal server error' });
    }
});

// Create a new category
router.post('/', jwtHandler, async (req, res) => {
    try {
        const { categoryName, categoryDescription } = req.body;
        const category = new Category({ categoryName, categoryDescription });
        await category.save();
        res.status(201).json({ message: 'Category created successfully' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Internal server error' });
    }
});

// Delete a category
router.delete('/:id', jwtHandler, async (req, res) => {
    try {
        await Category.findByIdAndDelete(req.params.id);
        res.json({ message: 'Category deleted successfully' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Internal server error' });
    }
});

module.exports = router;
