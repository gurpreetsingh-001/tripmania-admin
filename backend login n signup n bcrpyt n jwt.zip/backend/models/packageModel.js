const mongoose = require('mongoose');

const packageSchema = new mongoose.Schema({
    packageName: {
         type: String,
          required: true 
        },
    images: [String],
    price: { 
        type: Number, 
        default: 0 
    },
    specialPrice: { 
        type: Number, 
        default: 0 
    },
    packageUSP: String,

    description: String,

    highlights: String,

    inclusion: String,

    cancellationPolicy: String,

    enabled: {
         type: Boolean,
          default: true 
        },
    timeSlots: [String] // Example, can be adjusted as per requirement
});

const Package = mongoose.model('Package', packageSchema);

module.exports = Package;
