const express = require('express');
const Package = require('../models/packageModel');
const jwtHandler = require('../utils/jwtHandler');

const router = express.Router();

// Get all packages
router.get('/', async (req, res) => {
    try {
        const packages = await Package.find();
        res.json(packages);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Internal server error' });
    }
});

// Create a new package
router.post('/', jwtHandler, async (req, res) => {
    try {
        const {
            packageName,
            images,
            price,
            specialPrice,
            packageUSP,
            description,
            highlights,
            inclusion,
            cancellationPolicy,
            enabled,
            timeSlots
        } = req.body;

        const package = new Package({
            packageName,
            images,
            price,
            specialPrice,
            packageUSP,
            description,
            highlights,
            inclusion,
            cancellationPolicy,
            enabled,
            timeSlots
        });

        await package.save();
        res.status(201).json({ message: 'Package created successfully' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Internal server error' });
    }
});

// Update a package
router.put('/:id', jwtHandler, async (req, res) => {
    try {
        const updatedPackage = await Package.findByIdAndUpdate(req.params.id, req.body, { new: true });
        res.json(updatedPackage);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Internal server error' });
    }
});

// Delete a package
router.delete('/:id', jwtHandler, async (req, res) => {
    try {
        await Package.findByIdAndDelete(req.params.id);
        res.json({ message: 'Package deleted successfully' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Internal server error' });
    }
});

module.exports = router;
